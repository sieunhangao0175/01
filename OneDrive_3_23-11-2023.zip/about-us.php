<?php include('include/header.php');
?>

<div class="container sign-in-up">
  <div class="row">
    <div class="col-md-5">
      <img src="img/about-us-actor.png" width="100%">
    </div>
    <div class="col-md-7" style="height:66.5vh;">
      <h1>Cửa hàng nội thất trực tuyến</h1>
      <p>
        Chào mừng bạn đến với Cửa hàng nội thất trực tuyến, nguồn cung cấp mọi thứ số một của bạn. Hệ thống quản lý cửa hàng nội thất trực tuyến là một quy trình trong đó chúng tôi có thể đặt hàng trực tuyến các mặt hàng nội thất khác nhau.
        Chúng tôi cố gắng cung cấp cho bạn những sản phẩm tốt nhất, tập trung vào bộ giường, bộ ăn, ghế, bàn, ghế sofa và tủ.

        Shop Nội thất Online đã đi được một chặng đường dài từ những ngày đầu thành lập. Cửa hàng Nội thất Trực tuyến bắt đầu cho mọi người lựa chọn Sản phẩm Nội thất trực tuyến tại nhà.

        Chúng tôi hy vọng bạn thích sản phẩm của chúng tôi cũng như chúng tôi thích cung cấp chúng cho bạn. Nếu bạn có bất kỳ câu hỏi hoặc ý kiến, xin vui lòng liên hệ với chúng tôi.

        Trân trọng,
        Ban quản lý Shop Nội thất Online

      </p>
    </div>
  </div>
</div>

<?php include('include/footer.php'); ?>
<a href="checkout.php">
                            <input type="button" name="proceed" value="Thanh Toán" style="font-size:12px;" class="btn btn-success pt-2 pb-2">
                         </a>
                         <a href="a.php">
                            <input type="button" name="proceed" value="Thanh Toán online" style="font-size:12px;" class="btn btn-success pt-2 pb-2">
                         </a>
<?php include('include/header.php'); ?>

       <div class="jumbotron">
           <h1 class="text-center mt-5">Contact us</h1>
       </div>
       
        <div class="container mt-3">
          <div class="row">
            <div class="col-md-6">
              <h3>Our Office</h3>
              <hr>
              <p>Lahore cantt,pakistan</p>
            </div>
            <div class="col-md-6">
                  <form action="" method="" class=" p-3">
                    <div class="form-group">
                      <input type="text" name="Fullname" placeholder="Full Name" class="form-control">
                     </div>
                     
                     <div class="form-group">
                      <input type="text" name="email" placeholder="Email" class="form-control">
                     </div>
                     
                     <div class="form-group">
                      <textarea class="form-control" rows="5" cols="20" placeholder="Message"></textarea>
                    </div>

                      <div class="form-group text-center mt-4">
                        <input type="submit" name="sigin" class="btn btn-primary" value="Send">
                      </div>

                  </form>
                </div>
         </div>
          
           <iframe src="https://www.google.com/maps/embed?pb=!1m23!1m12!1m3!1d54420.52040063149!2d74.32475536753505!3d31.516399432441787!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!4m8!3e6!4m0!4m5!1s0x39190483e58107d9%3A0xc23abe6ccc7e2462!2sLahore%2C%20Pakistan!3m2!1d31.5203696!2d74.35874729999999!5e0!3m2!1sen!2s!4v1588778937037!5m2!1sen!2s" width="100%" height="450" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe> 
           
         
       </div>
         
       <?php include('include/footer.php');?>